create function anynonarray_in(cstring) returns anynonarray
    language internal
as
$$anynonarray_in$$;

comment on function anynonarray_in(cstring) is 'I/O';

