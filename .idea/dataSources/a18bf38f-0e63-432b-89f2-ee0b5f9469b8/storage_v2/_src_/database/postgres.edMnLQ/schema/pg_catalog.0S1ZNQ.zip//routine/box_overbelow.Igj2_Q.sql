create function box_overbelow(box, box) returns boolean
    language internal
as
$$box_overbelow$$;

comment on function box_overbelow(box, box) is 'implementation of &<| operator';

