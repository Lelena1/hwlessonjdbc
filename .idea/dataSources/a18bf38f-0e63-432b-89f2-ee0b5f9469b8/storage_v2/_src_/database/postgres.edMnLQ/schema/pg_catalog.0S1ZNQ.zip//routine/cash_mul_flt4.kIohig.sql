create function cash_mul_flt4(money, real) returns money
    language internal
as
$$cash_mul_flt4$$;

comment on function cash_mul_flt4(money, float4) is 'implementation of * operator';

