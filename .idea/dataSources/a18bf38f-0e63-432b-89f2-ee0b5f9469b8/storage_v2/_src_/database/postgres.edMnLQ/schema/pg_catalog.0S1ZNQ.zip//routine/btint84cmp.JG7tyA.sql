create function btint84cmp(bigint, integer) returns integer
    language internal
as
$$btint84cmp$$;

comment on function btint84cmp(int8, int4) is 'less-equal-greater';

