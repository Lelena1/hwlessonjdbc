create function array_agg_array_finalfn(internal, anyarray) returns anyarray
    language internal
as
$$array_agg_array_finalfn$$;

comment on function array_agg_array_finalfn(internal, anyarray) is 'aggregate final function';

