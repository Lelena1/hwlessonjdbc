create function anytextcat(anynonarray, text) returns text
    language sql
as
$$select $1::pg_catalog.text operator(pg_catalog.||) $2$$;

comment on function anytextcat(anynonarray, text) is 'implementation of || operator';

