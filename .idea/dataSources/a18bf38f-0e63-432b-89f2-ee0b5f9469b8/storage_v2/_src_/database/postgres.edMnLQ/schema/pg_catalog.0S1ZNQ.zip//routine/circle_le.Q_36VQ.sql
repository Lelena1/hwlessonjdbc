create function circle_le(circle, circle) returns boolean
    language internal
as
$$circle_le$$;

comment on function circle_le(circle, circle) is 'implementation of <= operator';

