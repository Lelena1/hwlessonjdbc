create function bernoulli(internal) returns tsm_handler
    language internal
as
$$tsm_bernoulli_handler$$;

comment on function bernoulli(internal) is 'BERNOULLI tablesample method handler';

