create function "RI_FKey_setdefault_upd"() returns trigger
    language internal
as
$$RI_FKey_setdefault_upd$$;

comment on function "RI_FKey_setdefault_upd"() is 'referential integrity ON UPDATE SET DEFAULT';

