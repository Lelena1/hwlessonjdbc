create function binary_upgrade_set_record_init_privs(boolean) returns void
    language internal
as
$$binary_upgrade_set_record_init_privs$$;

comment on function binary_upgrade_set_record_init_privs(bool) is 'for use by pg_upgrade';

