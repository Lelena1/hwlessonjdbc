create function brin_minmax_add_value(internal, internal, internal, internal) returns boolean
    language internal
as
$$brin_minmax_add_value$$;

comment on function brin_minmax_add_value(internal, internal, internal, internal) is 'BRIN minmax support';

