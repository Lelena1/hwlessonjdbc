create function cash_in(cstring) returns money
    language internal
as
$$cash_in$$;

comment on function cash_in(cstring) is 'I/O';

