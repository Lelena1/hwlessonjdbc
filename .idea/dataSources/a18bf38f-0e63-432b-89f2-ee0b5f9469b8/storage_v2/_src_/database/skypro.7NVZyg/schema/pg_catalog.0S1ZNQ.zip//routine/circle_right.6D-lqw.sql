create function circle_right(circle, circle) returns boolean
    language internal
as
$$circle_right$$;

comment on function circle_right(circle, circle) is 'implementation of >> operator';

