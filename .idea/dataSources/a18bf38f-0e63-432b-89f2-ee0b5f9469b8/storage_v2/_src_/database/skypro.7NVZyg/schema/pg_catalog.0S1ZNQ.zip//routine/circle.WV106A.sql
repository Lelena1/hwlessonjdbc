create function circle(box) returns circle
    language internal
as
$$box_circle$$;

comment on function circle(polygon) is 'convert polygon to circle';

