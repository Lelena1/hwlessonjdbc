create function bpchar_pattern_lt(character, character) returns boolean
    language internal
as
$$bpchar_pattern_lt$$;

comment on function bpchar_pattern_lt(bpchar, bpchar) is 'implementation of ~<~ operator';

