create function btvarstrequalimage(oid) returns boolean
    language internal
as
$$btvarstrequalimage$$;

comment on function btvarstrequalimage(oid) is 'equal image';

