create function bttextsortsupport(internal) returns void
    language internal
as
$$bttextsortsupport$$;

comment on function bttextsortsupport(internal) is 'sort support';

