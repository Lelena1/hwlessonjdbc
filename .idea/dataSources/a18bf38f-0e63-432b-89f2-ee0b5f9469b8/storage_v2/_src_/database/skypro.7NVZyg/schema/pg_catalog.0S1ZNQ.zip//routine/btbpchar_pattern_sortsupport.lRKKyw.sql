create function btbpchar_pattern_sortsupport(internal) returns void
    language internal
as
$$btbpchar_pattern_sortsupport$$;

comment on function btbpchar_pattern_sortsupport(internal) is 'sort support';

