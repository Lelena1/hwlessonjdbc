create function byteacat(bytea, bytea) returns bytea
    language internal
as
$$byteacat$$;

comment on function byteacat(bytea, bytea) is 'implementation of || operator';

