create function box_out(box) returns cstring
    language internal
as
$$box_out$$;

comment on function box_out(box) is 'I/O';

