create function array_to_string(anyarray, text) returns text
    language internal
as
$$array_to_text$$;

comment on function array_to_string(anyarray, text, text) is 'concatenate array elements, using delimiter and null string, into text';

