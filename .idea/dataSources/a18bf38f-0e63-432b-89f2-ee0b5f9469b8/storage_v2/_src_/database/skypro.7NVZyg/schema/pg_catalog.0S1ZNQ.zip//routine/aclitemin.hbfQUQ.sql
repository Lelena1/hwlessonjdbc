create function aclitemin(cstring) returns aclitem
    language internal
as
$$aclitemin$$;

comment on function aclitemin(cstring) is 'I/O';

