create function brin_minmax_multi_distance_pg_lsn(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_pg_lsn$$;

comment on function brin_minmax_multi_distance_pg_lsn(internal, internal) is 'BRIN multi minmax pg_lsn distance';

